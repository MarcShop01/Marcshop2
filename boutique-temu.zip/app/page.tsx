import { Header } from "@/components/header"
import { ProductGrid } from "@/components/product-grid"
import { CategoryNav } from "@/components/category-nav"
import { PromoSection } from "@/components/promo-section"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <PromoSection />
      <CategoryNav />
      <main className="container mx-auto px-4 py-6">
        <ProductGrid />
      </main>
    </div>
  )
}
