import { CheckoutPage } from "@/components/checkout-page"

export default function CommandePage() {
  return <CheckoutPage />
}
