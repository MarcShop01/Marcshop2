import { OrderHistoryPage } from "@/components/order-history-page"

export default function MesCommandesPage() {
  return <OrderHistoryPage />
}
