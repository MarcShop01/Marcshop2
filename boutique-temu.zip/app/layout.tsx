import type React from "react"
import type { Metadata } from "next"
import { Geist } from "next/font/google"
import { Manrope } from "next/font/google"
import { CartProvider } from "@/contexts/cart-context"
import { UserRegistrationProvider } from "@/contexts/user-registration-context"
import "./globals.css"

const geist = Geist({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-geist",
})

const manrope = Manrope({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-manrope",
})

export const metadata: Metadata = {
  title: "MarcShop - Votre Boutique en Ligne",
  description: "MarcShop - Votre marketplace pour tous vos achats en ligne",
  generator: "v0.app",
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="fr" className={`${geist.variable} ${manrope.variable} antialiased`}>
      <body>
        <UserRegistrationProvider>
          <CartProvider>{children}</CartProvider>
        </UserRegistrationProvider>
      </body>
    </html>
  )
}
