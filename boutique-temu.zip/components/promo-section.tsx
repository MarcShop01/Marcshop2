import { Badge } from "@/components/ui/badge"

export function PromoSection() {
  return (
    <section className="bg-accent text-accent-foreground py-3">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-center gap-4 text-sm font-medium">
          <Badge variant="secondary" className="bg-background text-foreground">
            NOUVEAU
          </Badge>
          <span>Livraison gratuite pour les commandes de plus de 50€</span>
          <Badge variant="secondary" className="bg-background text-foreground">
            -20%
          </Badge>
        </div>
      </div>
    </section>
  )
}
