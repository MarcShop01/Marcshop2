"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Header } from "@/components/header"
import { Package, Truck, CheckCircle, Clock } from "lucide-react"
import Link from "next/link"

// Données de démonstration
const orders = [
  {
    id: "CMD-2024-001",
    date: "2024-01-15",
    status: "delivered",
    total: 299.99,
    items: [
      {
        name: "Smartphone Android 128GB",
        quantity: 1,
        price: 299.99,
        image: "/modern-smartphone.png",
      },
    ],
  },
  {
    id: "CMD-2024-002",
    date: "2024-01-10",
    status: "shipped",
    total: 169.98,
    items: [
      {
        name: "Casque Bluetooth Sans Fil",
        quantity: 1,
        price: 79.99,
        image: "/bluetooth-headphones.png",
      },
      {
        name: "Sac à Dos Ordinateur",
        quantity: 1,
        price: 89.99,
        image: "/laptop-backpack.png",
      },
    ],
  },
  {
    id: "CMD-2024-003",
    date: "2024-01-05",
    status: "processing",
    total: 159.99,
    items: [
      {
        name: "Montre Connectée Sport",
        quantity: 1,
        price: 159.99,
        image: "/modern-smartwatch.png",
      },
    ],
  },
]

const statusConfig = {
  processing: {
    label: "En préparation",
    color: "bg-yellow-500",
    icon: <Clock className="h-4 w-4" />,
  },
  shipped: {
    label: "Expédiée",
    color: "bg-blue-500",
    icon: <Truck className="h-4 w-4" />,
  },
  delivered: {
    label: "Livrée",
    color: "bg-green-500",
    icon: <CheckCircle className="h-4 w-4" />,
  },
}

export function OrderHistoryPage() {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold font-sans mb-8">Mes commandes</h1>

        {orders.length === 0 ? (
          <div className="text-center py-16">
            <Package className="h-24 w-24 mx-auto text-muted-foreground mb-4" />
            <h2 className="text-2xl font-bold font-sans mb-2">Aucune commande</h2>
            <p className="text-muted-foreground mb-6">Vous n'avez pas encore passé de commande</p>
            <Link href="/">
              <Button size="lg" className="font-serif">
                Découvrir nos produits
              </Button>
            </Link>
          </div>
        ) : (
          <div className="space-y-6">
            {orders.map((order) => (
              <Card key={order.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="font-sans">{order.id}</CardTitle>
                      <p className="text-sm text-muted-foreground">
                        Commandé le {new Date(order.date).toLocaleDateString("fr-FR")}
                      </p>
                    </div>
                    <Badge className={`${statusConfig[order.status as keyof typeof statusConfig].color} text-white`}>
                      {statusConfig[order.status as keyof typeof statusConfig].icon}
                      <span className="ml-1">{statusConfig[order.status as keyof typeof statusConfig].label}</span>
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Articles */}
                    <div className="space-y-3">
                      {order.items.map((item, index) => (
                        <div key={index} className="flex gap-4">
                          <img
                            src={item.image || "/placeholder.svg"}
                            alt={item.name}
                            className="w-16 h-16 object-cover rounded-md"
                          />
                          <div className="flex-1">
                            <h3 className="font-medium font-serif">{item.name}</h3>
                            <p className="text-sm text-muted-foreground">Quantité: {item.quantity}</p>
                          </div>
                          <div className="text-right">
                            <p className="font-bold">{item.price.toFixed(2)}€</p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Total et actions */}
                    <div className="flex items-center justify-between pt-4 border-t">
                      <div className="text-lg font-bold font-sans">
                        Total: <span className="text-primary">{order.total.toFixed(2)}€</span>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="font-serif bg-transparent">
                          Voir détails
                        </Button>
                        {order.status === "delivered" && (
                          <Button variant="outline" size="sm" className="font-serif bg-transparent">
                            Racheter
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
