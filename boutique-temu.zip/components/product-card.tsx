"use client"

import { Star, ShoppingCart } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useCart } from "@/contexts/cart-context"

interface Product {
  id: number
  name: string
  price: number
  originalPrice: number
  image: string
  rating: number
  reviews: number
  badge: string
  discount: number
}

interface ProductCardProps {
  product: Product
}

export function ProductCard({ product }: ProductCardProps) {
  const { dispatch } = useCart()

  const handleAddToCart = () => {
    dispatch({
      type: "ADD_ITEM",
      payload: {
        id: product.id,
        name: product.name,
        price: product.price,
        originalPrice: product.originalPrice,
        image: product.image,
      },
    })
  }

  return (
    <Card className="group hover:shadow-lg transition-shadow duration-200 border-0 shadow-sm">
      <CardContent className="p-3">
        {/* Image et Badge */}
        <div className="relative mb-3">
          <img
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            className="w-full h-40 object-cover rounded-md"
          />
          <Badge className="absolute top-2 left-2 text-xs font-bold bg-accent text-accent-foreground">
            {product.badge}
          </Badge>
          <Badge className="absolute top-2 right-2 text-xs font-bold bg-destructive text-destructive-foreground">
            -{product.discount}%
          </Badge>
        </div>

        {/* Nom du produit */}
        <h3 className="font-serif text-sm font-medium line-clamp-2 mb-2 min-h-[2.5rem]">{product.name}</h3>

        {/* Rating */}
        <div className="flex items-center gap-1 mb-2">
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={`h-3 w-3 ${
                  i < Math.floor(product.rating) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                }`}
              />
            ))}
          </div>
          <span className="text-xs text-muted-foreground">({product.reviews})</span>
        </div>

        {/* Prix */}
        <div className="flex items-center gap-2 mb-3">
          <span className="text-lg font-bold text-primary font-sans">${product.price.toFixed(2)}</span>
          <span className="text-sm text-muted-foreground line-through">${product.originalPrice.toFixed(2)}</span>
        </div>

        {/* Bouton d'achat */}
        <Button size="sm" className="w-full font-serif text-xs" onClick={handleAddToCart}>
          <ShoppingCart className="h-3 w-3 mr-1" />
          Ajouter
        </Button>
      </CardContent>
    </Card>
  )
}
