"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CreditCard, Lock } from "lucide-react"

interface CardPaymentFormProps {
  onValidationChange: (isValid: boolean) => void
}

export function CardPaymentForm({ onValidationChange }: CardPaymentFormProps) {
  const [cardData, setCardData] = useState({
    number: "",
    expiry: "",
    cvv: "",
    name: "",
  })

  const formatCardNumber = (value: string) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "")
    const matches = v.match(/\d{4,16}/g)
    const match = (matches && matches[0]) || ""
    const parts = []

    for (let i = 0, len = match.length; i < len; i += 4) {
      parts.push(match.substring(i, i + 4))
    }

    if (parts.length) {
      return parts.join(" ")
    } else {
      return v
    }
  }

  const formatExpiry = (value: string) => {
    const v = value.replace(/\s+/g, "").replace(/[^0-9]/gi, "")
    if (v.length >= 2) {
      return `${v.substring(0, 2)}/${v.substring(2, 4)}`
    }
    return v
  }

  const handleInputChange = (field: keyof typeof cardData, value: string) => {
    let formattedValue = value

    if (field === "number") {
      formattedValue = formatCardNumber(value)
    } else if (field === "expiry") {
      formattedValue = formatExpiry(value)
    } else if (field === "cvv") {
      formattedValue = value.replace(/[^0-9]/g, "").substring(0, 4)
    }

    const newCardData = { ...cardData, [field]: formattedValue }
    setCardData(newCardData)

    // Validation simple
    const isValid =
      newCardData.number.replace(/\s/g, "").length >= 16 &&
      newCardData.expiry.length === 5 &&
      newCardData.cvv.length >= 3 &&
      newCardData.name.length > 0

    onValidationChange(isValid)
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 font-sans">
          <CreditCard className="h-5 w-5" />
          Informations de carte
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label htmlFor="cardName" className="font-serif">
            Nom sur la carte *
          </Label>
          <Input
            id="cardName"
            placeholder="Jean Dupont"
            value={cardData.name}
            onChange={(e) => handleInputChange("name", e.target.value)}
          />
        </div>
        <div>
          <Label htmlFor="cardNumber" className="font-serif">
            Numéro de carte *
          </Label>
          <Input
            id="cardNumber"
            placeholder="1234 5678 9012 3456"
            value={cardData.number}
            onChange={(e) => handleInputChange("number", e.target.value)}
            maxLength={19}
          />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <Label htmlFor="cardExpiry" className="font-serif">
              Date d'expiration *
            </Label>
            <Input
              id="cardExpiry"
              placeholder="MM/AA"
              value={cardData.expiry}
              onChange={(e) => handleInputChange("expiry", e.target.value)}
              maxLength={5}
            />
          </div>
          <div>
            <Label htmlFor="cardCvv" className="font-serif">
              CVV *
            </Label>
            <Input
              id="cardCvv"
              placeholder="123"
              value={cardData.cvv}
              onChange={(e) => handleInputChange("cvv", e.target.value)}
              maxLength={4}
            />
          </div>
        </div>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          <Lock className="h-4 w-4" />
          <span>Vos informations sont sécurisées et cryptées</span>
        </div>
      </CardContent>
    </Card>
  )
}
