"use client"

import { useState } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Phone, MapPin } from "lucide-react"

interface NatcashPaymentFormProps {
  onValidationChange: (isValid: boolean) => void
}

export function NatcashPaymentForm({ onValidationChange }: NatcashPaymentFormProps) {
  const [natcashData, setNatcashData] = useState({
    phoneNumber: "",
    pin: "",
  })

  const handleInputChange = (field: keyof typeof natcashData, value: string) => {
    let formattedValue = value

    if (field === "phoneNumber") {
      // Format haïtien: +509 XXXX XXXX
      formattedValue = value.replace(/[^0-9]/g, "").substring(0, 8)
    } else if (field === "pin") {
      formattedValue = value.replace(/[^0-9]/g, "").substring(0, 4)
    }

    const newNatcashData = { ...natcashData, [field]: formattedValue }
    setNatcashData(newNatcashData)

    // Validation
    const isValid = newNatcashData.phoneNumber.length === 8 && newNatcashData.pin.length === 4

    onValidationChange(isValid)
  }

  const formatPhoneDisplay = (phone: string) => {
    if (phone.length >= 4) {
      return `+509 ${phone.substring(0, 4)} ${phone.substring(4)}`
    }
    return phone ? `+509 ${phone}` : ""
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 font-sans">
          <div className="h-6 w-6 bg-green-600 rounded text-white text-sm flex items-center justify-center font-bold">
            N
          </div>
          Paiement Natcash
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert className="border-blue-200 bg-blue-50">
          <MapPin className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-800">
            Service de paiement mobile disponible en Haïti uniquement
          </AlertDescription>
        </Alert>

        <div>
          <Label htmlFor="natcashPhone" className="font-serif">
            Numéro de téléphone Natcash *
          </Label>
          <div className="relative">
            <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              id="natcashPhone"
              placeholder="XXXX XXXX"
              value={natcashData.phoneNumber}
              onChange={(e) => handleInputChange("phoneNumber", e.target.value)}
              className="pl-10"
            />
          </div>
          {natcashData.phoneNumber && (
            <p className="text-sm text-muted-foreground mt-1">
              Numéro formaté: {formatPhoneDisplay(natcashData.phoneNumber)}
            </p>
          )}
        </div>

        <div>
          <Label htmlFor="natcashPin" className="font-serif">
            Code PIN Natcash *
          </Label>
          <Input
            id="natcashPin"
            type="password"
            placeholder="••••"
            value={natcashData.pin}
            onChange={(e) => handleInputChange("pin", e.target.value)}
            maxLength={4}
          />
        </div>

        <Alert>
          <AlertDescription>
            <strong>Instructions:</strong>
            <br />
            1. Entrez votre numéro de téléphone Natcash
            <br />
            2. Saisissez votre code PIN à 4 chiffres
            <br />
            3. Vous recevrez un SMS de confirmation pour valider le paiement
          </AlertDescription>
        </Alert>
      </CardContent>
    </Card>
  )
}
