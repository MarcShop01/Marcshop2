"use client"

import { useEffect } from "react"
import { useSearchParams } from "next/navigation"
import { useCart } from "@/contexts/cart-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Header } from "@/components/header"
import { CheckCircle, Package, Truck, CreditCard } from "lucide-react"
import Link from "next/link"

export function OrderConfirmationPage() {
  const searchParams = useSearchParams()
  const orderId = searchParams.get("id")
  const { dispatch } = useCart()

  // Vider le panier après confirmation de commande
  useEffect(() => {
    dispatch({ type: "CLEAR_CART" })
  }, [dispatch])

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          {/* Confirmation */}
          <Card className="text-center mb-8">
            <CardContent className="pt-8 pb-8">
              <CheckCircle className="h-16 w-16 text-primary mx-auto mb-4" />
              <h1 className="text-3xl font-bold font-sans mb-2">Commande confirmée !</h1>
              <p className="text-muted-foreground mb-4">
                Merci pour votre achat. Votre commande a été reçue et est en cours de traitement.
              </p>
              <div className="bg-muted p-4 rounded-lg">
                <p className="font-serif">
                  Numéro de commande: <span className="font-bold font-sans">{orderId}</span>
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Étapes de livraison */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="font-sans">Suivi de votre commande</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center gap-4 p-4 bg-primary/10 rounded-lg border-l-4 border-primary">
                  <CheckCircle className="h-6 w-6 text-primary" />
                  <div>
                    <div className="font-medium font-serif">Commande confirmée</div>
                    <div className="text-sm text-muted-foreground">Votre commande a été reçue</div>
                  </div>
                </div>
                <div className="flex items-center gap-4 p-4 bg-muted/50 rounded-lg">
                  <Package className="h-6 w-6 text-muted-foreground" />
                  <div>
                    <div className="font-medium font-serif">Préparation</div>
                    <div className="text-sm text-muted-foreground">Votre commande est en cours de préparation</div>
                  </div>
                </div>
                <div className="flex items-center gap-4 p-4 bg-muted/50 rounded-lg">
                  <Truck className="h-6 w-6 text-muted-foreground" />
                  <div>
                    <div className="font-medium font-serif">Expédition</div>
                    <div className="text-sm text-muted-foreground">Votre commande sera bientôt expédiée</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Informations importantes */}
          <Card className="mb-8">
            <CardHeader>
              <CardTitle className="font-sans">Informations importantes</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-start gap-3">
                <CreditCard className="h-5 w-5 text-primary mt-0.5" />
                <div>
                  <div className="font-medium font-serif">Paiement</div>
                  <div className="text-sm text-muted-foreground">
                    Votre paiement a été traité avec succès. Vous recevrez un reçu par email.
                  </div>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Truck className="h-5 w-5 text-primary mt-0.5" />
                <div>
                  <div className="font-medium font-serif">Livraison</div>
                  <div className="text-sm text-muted-foreground">
                    Livraison standard gratuite (3-5 jours ouvrés). Vous recevrez un email de suivi.
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Link href="/" className="flex-1">
              <Button variant="outline" size="lg" className="w-full font-serif bg-transparent">
                Continuer mes achats
              </Button>
            </Link>
            <Link href="/mes-commandes" className="flex-1">
              <Button size="lg" className="w-full font-serif">
                Voir mes commandes
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  )
}
