"use client"

import type React from "react"

import { useState } from "react"
import { useCart } from "@/contexts/cart-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Separator } from "@/components/ui/separator"
import { Header } from "@/components/header"
import { CardPaymentForm } from "@/components/payment-forms/card-payment-form"
import { PayPalPaymentForm } from "@/components/payment-forms/paypal-payment-form"
import { NatcashPaymentForm } from "@/components/payment-forms/natcash-payment-form"
import { ArrowLeft, CreditCard, Truck, MapPin } from "lucide-react"
import Link from "next/link"
import { useRouter } from "next/navigation"

interface ShippingInfo {
  firstName: string
  lastName: string
  email: string
  phone: string
  address: string
  city: string
  postalCode: string
  country: string
  notes: string
}

interface PaymentMethod {
  type: "card" | "paypal" | "natcash"
  label: string
  icon: React.ReactNode
}

const paymentMethods: PaymentMethod[] = [
  {
    type: "card",
    label: "Carte bancaire",
    icon: <CreditCard className="h-5 w-5" />,
  },
  {
    type: "paypal",
    label: "PayPal",
    icon: (
      <div className="h-5 w-5 bg-blue-600 rounded text-white text-xs flex items-center justify-center font-bold">P</div>
    ),
  },
  {
    type: "natcash",
    label: "Natcash (Haïti)",
    icon: (
      <div className="h-5 w-5 bg-green-600 rounded text-white text-xs flex items-center justify-center font-bold">
        N
      </div>
    ),
  },
]

export function CheckoutPage() {
  const { state } = useCart()
  const router = useRouter()
  const [selectedPayment, setSelectedPayment] = useState<string>("card")
  const [isPaymentValid, setIsPaymentValid] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [shippingInfo, setShippingInfo] = useState<ShippingInfo>({
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    postalCode: "",
    country: "France",
    notes: "",
  })

  const handleInputChange = (field: keyof ShippingInfo, value: string) => {
    setShippingInfo((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!isPaymentValid) {
      alert("Veuillez compléter les informations de paiement")
      return
    }

    setIsProcessing(true)

    // Simulation du traitement de paiement
    try {
      await new Promise((resolve) => setTimeout(resolve, 3000))

      // Simuler le traitement selon la méthode de paiement
      const orderId = Math.random().toString(36).substr(2, 9).toUpperCase()

      console.log("[v0] Traitement paiement:", {
        method: selectedPayment,
        total: (state.total * 1.2).toFixed(2),
        orderId,
        shipping: shippingInfo,
      })

      router.push(`/commande/confirmation?id=${orderId}`)
    } catch (error) {
      console.error("[v0] Erreur paiement:", error)
      alert("Erreur lors du traitement du paiement. Veuillez réessayer.")
    } finally {
      setIsProcessing(false)
    }
  }

  const renderPaymentForm = () => {
    const totalWithTax = state.total * 1.2

    switch (selectedPayment) {
      case "card":
        return <CardPaymentForm onValidationChange={setIsPaymentValid} />
      case "paypal":
        return <PayPalPaymentForm onValidationChange={setIsPaymentValid} total={totalWithTax} />
      case "natcash":
        return <NatcashPaymentForm onValidationChange={setIsPaymentValid} />
      default:
        return null
    }
  }

  if (state.items.length === 0) {
    return (
      <div className="min-h-screen bg-background">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="text-center py-16">
            <h2 className="text-2xl font-bold font-sans mb-2">Votre panier est vide</h2>
            <p className="text-muted-foreground mb-6">Ajoutez des produits avant de passer commande</p>
            <Link href="/">
              <Button size="lg" className="font-serif">
                Retour aux achats
              </Button>
            </Link>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center gap-4 mb-6">
          <Link href="/panier">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <h1 className="text-3xl font-bold font-sans">Finaliser ma commande</h1>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid lg:grid-cols-3 gap-8">
            {/* Formulaire de commande */}
            <div className="lg:col-span-2 space-y-6">
              {/* Informations de livraison */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 font-sans">
                    <MapPin className="h-5 w-5" />
                    Adresse de livraison
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName" className="font-serif">
                        Prénom *
                      </Label>
                      <Input
                        id="firstName"
                        required
                        value={shippingInfo.firstName}
                        onChange={(e) => handleInputChange("firstName", e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="lastName" className="font-serif">
                        Nom *
                      </Label>
                      <Input
                        id="lastName"
                        required
                        value={shippingInfo.lastName}
                        onChange={(e) => handleInputChange("lastName", e.target.value)}
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="email" className="font-serif">
                      Email *
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      required
                      value={shippingInfo.email}
                      onChange={(e) => handleInputChange("email", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="phone" className="font-serif">
                      Téléphone *
                    </Label>
                    <Input
                      id="phone"
                      type="tel"
                      required
                      value={shippingInfo.phone}
                      onChange={(e) => handleInputChange("phone", e.target.value)}
                    />
                  </div>
                  <div>
                    <Label htmlFor="address" className="font-serif">
                      Adresse *
                    </Label>
                    <Input
                      id="address"
                      required
                      value={shippingInfo.address}
                      onChange={(e) => handleInputChange("address", e.target.value)}
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="city" className="font-serif">
                        Ville *
                      </Label>
                      <Input
                        id="city"
                        required
                        value={shippingInfo.city}
                        onChange={(e) => handleInputChange("city", e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="postalCode" className="font-serif">
                        Code postal *
                      </Label>
                      <Input
                        id="postalCode"
                        required
                        value={shippingInfo.postalCode}
                        onChange={(e) => handleInputChange("postalCode", e.target.value)}
                      />
                    </div>
                  </div>
                  <div>
                    <Label htmlFor="notes" className="font-serif">
                      Instructions de livraison (optionnel)
                    </Label>
                    <Textarea
                      id="notes"
                      placeholder="Étage, code d'accès, instructions spéciales..."
                      value={shippingInfo.notes}
                      onChange={(e) => handleInputChange("notes", e.target.value)}
                    />
                  </div>
                </CardContent>
              </Card>

              {/* Mode de livraison */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 font-sans">
                    <Truck className="h-5 w-5" />
                    Mode de livraison
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between p-4 border rounded-lg bg-accent/10 border-accent">
                      <div>
                        <div className="font-medium font-serif">Livraison standard</div>
                        <div className="text-sm text-muted-foreground">3-5 jours ouvrés</div>
                      </div>
                      <div className="text-primary font-bold">Gratuite</div>
                    </div>
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <div className="font-medium font-serif">Livraison express</div>
                        <div className="text-sm text-muted-foreground">1-2 jours ouvrés</div>
                      </div>
                      <div className="font-bold">9.99€</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Méthode de paiement */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 font-sans">
                    <CreditCard className="h-5 w-5" />
                    Méthode de paiement
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <RadioGroup value={selectedPayment} onValueChange={setSelectedPayment}>
                    {paymentMethods.map((method) => (
                      <div key={method.type} className="flex items-center space-x-3 p-3 border rounded-lg">
                        <RadioGroupItem value={method.type} id={method.type} />
                        <Label htmlFor={method.type} className="flex items-center gap-3 cursor-pointer font-serif">
                          {method.icon}
                          {method.label}
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                </CardContent>
              </Card>

              {renderPaymentForm()}
            </div>

            {/* Résumé de la commande */}
            <div className="lg:col-span-1">
              <Card className="sticky top-24">
                <CardHeader>
                  <CardTitle className="font-sans">Résumé de la commande</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Articles */}
                  <div className="space-y-3">
                    {state.items.map((item) => (
                      <div key={item.id} className="flex gap-3">
                        <img
                          src={item.image || "/placeholder.svg"}
                          alt={item.name}
                          className="w-12 h-12 object-cover rounded"
                        />
                        <div className="flex-1">
                          <div className="text-sm font-medium font-serif line-clamp-2">{item.name}</div>
                          <div className="text-sm text-muted-foreground">Qté: {item.quantity}</div>
                        </div>
                        <div className="text-sm font-bold">{(item.price * item.quantity).toFixed(2)}€</div>
                      </div>
                    ))}
                  </div>

                  <Separator />

                  {/* Totaux */}
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="font-serif">Sous-total</span>
                      <span>{state.total.toFixed(2)}€</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-serif">Livraison</span>
                      <span className="text-primary">Gratuite</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="font-serif">TVA (20%)</span>
                      <span>{(state.total * 0.2).toFixed(2)}€</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between text-lg font-bold">
                      <span className="font-sans">Total</span>
                      <span className="text-primary">{(state.total * 1.2).toFixed(2)}€</span>
                    </div>
                  </div>

                  <Button
                    type="submit"
                    size="lg"
                    className="w-full font-serif"
                    disabled={!isPaymentValid || isProcessing}
                  >
                    {isProcessing ? "Traitement en cours..." : "Confirmer la commande"}
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}
