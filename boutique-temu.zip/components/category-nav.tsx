import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"

const categories = [
  "Tous",
  "Électronique",
  "Mode",
  "Maison & Jardin",
  "Sports",
  "Beauté",
  "Jouets",
  "Automobile",
  "Livres",
  "Santé",
]

export function CategoryNav() {
  return (
    <nav className="border-b bg-card">
      <div className="container mx-auto px-4">
        <ScrollArea className="w-full">
          <div className="flex gap-2 py-4">
            {categories.map((category) => (
              <Button
                key={category}
                variant={category === "Tous" ? "default" : "ghost"}
                size="sm"
                className="whitespace-nowrap font-serif"
              >
                {category}
              </Button>
            ))}
          </div>
        </ScrollArea>
      </div>
    </nav>
  )
}
