"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { LayoutDashboard, Package, ShoppingCart, Users, Settings, LogOut, Store } from "lucide-react"
import Link from "next/link"

interface AdminSidebarProps {
  activeSection: string
  onSectionChange: (section: string) => void
}

const menuItems = [
  { id: "dashboard", label: "Tableau de bord", icon: LayoutDashboard },
  { id: "products", label: "Produits", icon: Package },
  { id: "orders", label: "Commandes", icon: ShoppingCart },
  { id: "users", label: "Utilisateurs", icon: Users },
  { id: "settings", label: "Paramètres", icon: Settings },
]

export function AdminSidebar({ activeSection, onSectionChange }: AdminSidebarProps) {
  return (
    <Card className="w-64 min-h-screen rounded-none border-r">
      <div className="p-6">
        {/* Logo */}
        <div className="flex items-center gap-2 mb-8">
          <Store className="h-8 w-8 text-primary" />
          <div>
            <h2 className="text-xl font-bold font-sans">Admin</h2>
            <p className="text-sm text-muted-foreground">MarketPlace</p>
          </div>
        </div>

        {/* Navigation */}
        <nav className="space-y-2">
          {menuItems.map((item) => {
            const Icon = item.icon
            return (
              <Button
                key={item.id}
                variant={activeSection === item.id ? "default" : "ghost"}
                className="w-full justify-start font-serif"
                onClick={() => onSectionChange(item.id)}
              >
                <Icon className="h-4 w-4 mr-3" />
                {item.label}
              </Button>
            )
          })}
        </nav>

        <Separator className="my-6" />

        {/* Actions */}
        <div className="space-y-2">
          <Link href="/">
            <Button variant="outline" className="w-full justify-start font-serif bg-transparent">
              <Store className="h-4 w-4 mr-3" />
              Voir le site
            </Button>
          </Link>
          <Button variant="ghost" className="w-full justify-start text-destructive hover:text-destructive">
            <LogOut className="h-4 w-4 mr-3" />
            Déconnexion
          </Button>
        </div>
      </div>
    </Card>
  )
}
