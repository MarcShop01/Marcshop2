"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Search, Filter, Eye, Mail, Users, UserCheck, Clock } from "lucide-react"

export function UsersManager() {
  const [searchTerm, setSearchTerm] = useState("")
  const [users, setUsers] = useState<any[]>([])

  useEffect(() => {
    const loadUsers = () => {
      const storedUsers = JSON.parse(localStorage.getItem("marcshop_users") || "[]")
      setUsers(storedUsers)
    }

    loadUsers()
    const interval = setInterval(loadUsers, 10000) // Mise à jour plus fréquente (10s)
    return () => clearInterval(interval)
  }, [])

  const filteredUsers = users.filter(
    (user) =>
      user.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (user.name && user.name.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  const activeUsers = users.filter((user) => {
    const lastActivity = new Date(user.lastActivity)
    const now = new Date()
    const diffHours = (now.getTime() - lastActivity.getTime()) / (1000 * 60 * 60)
    return diffHours < 24
  })

  const getInitials = (user: any) => {
    if (user.name) {
      const names = user.name.split(" ")
      return names.length > 1
        ? (names[0][0] + names[names.length - 1][0]).toUpperCase()
        : user.name.substring(0, 2).toUpperCase()
    }
    return user.email.substring(0, 2).toUpperCase()
  }

  const getTimeAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60))

    if (diffMinutes < 60) return `${diffMinutes}min`
    if (diffMinutes < 1440) return `${Math.floor(diffMinutes / 60)}h`
    return `${Math.floor(diffMinutes / 1440)}j`
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-sans">Utilisateurs MarcShop</h1>
          <p className="text-muted-foreground">Gérez votre base d'utilisateurs en temps réel</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Users className="h-8 w-8 text-primary" />
              <div>
                <p className="text-2xl font-bold font-sans">{users.length}</p>
                <p className="text-sm font-medium font-serif">Total utilisateurs</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <UserCheck className="h-8 w-8 text-green-600" />
              <div>
                <p className="text-2xl font-bold font-sans text-green-600">{activeUsers.length}</p>
                <p className="text-sm font-medium font-serif">Actifs (24h)</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Clock className="h-8 w-8 text-blue-600" />
              <div>
                <p className="text-2xl font-bold font-sans text-blue-600">
                  {
                    users.filter((u) => {
                      const registered = new Date(u.registeredAt)
                      const today = new Date()
                      return registered.toDateString() === today.toDateString()
                    }).length
                  }
                </p>
                <p className="text-sm font-medium font-serif">Nouveaux aujourd'hui</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <Mail className="h-8 w-8 text-purple-600" />
              <div>
                <p className="text-2xl font-bold font-sans text-purple-600">
                  {Math.round((activeUsers.length / Math.max(users.length, 1)) * 100)}%
                </p>
                <p className="text-sm font-medium font-serif">Taux d'activité</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Rechercher par nom ou email..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Button variant="outline" className="font-serif bg-transparent">
              <Filter className="h-4 w-4 mr-2" />
              Filtres
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Users Table */}
      <Card>
        <CardHeader>
          <CardTitle className="font-sans">Utilisateurs Enregistrés ({filteredUsers.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredUsers.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              {users.length === 0 ? "Aucun utilisateur enregistré pour le moment" : "Aucun utilisateur trouvé"}
            </div>
          ) : (
            <div className="space-y-4">
              {filteredUsers.map((user) => {
                const isActive = activeUsers.some((u) => u.id === user.id)
                return (
                  <div key={user.id} className="flex items-center gap-4 p-4 border rounded-lg">
                    <Avatar className="h-12 w-12">
                      <AvatarFallback className="bg-primary text-primary-foreground font-bold">
                        {getInitials(user)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className="font-medium font-serif">{user.name || user.email}</h3>
                        <Badge className={`${isActive ? "bg-green-500" : "bg-gray-500"} text-white`}>
                          {isActive ? "Actif" : "Inactif"}
                        </Badge>
                      </div>
                      {user.name && <p className="text-sm text-muted-foreground mb-1">{user.email}</p>}
                      <p className="text-xs text-muted-foreground">
                        Inscrit le {new Date(user.registeredAt).toLocaleDateString("fr-FR")} à{" "}
                        {new Date(user.registeredAt).toLocaleTimeString("fr-FR")}
                      </p>
                    </div>
                    <div className="text-center">
                      <div className="font-medium font-serif">Dernière activité</div>
                      <div className="text-sm">{getTimeAgo(user.lastActivity)}</div>
                    </div>
                    <div className="text-center">
                      <div className="font-medium font-serif">Statut</div>
                      <div className={`text-sm font-bold ${isActive ? "text-green-600" : "text-gray-500"}`}>
                        {isActive ? "En ligne" : "Hors ligne"}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="bg-transparent">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm" className="bg-transparent">
                        <Mail className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
