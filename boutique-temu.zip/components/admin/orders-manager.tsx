"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Eye, Package, Truck } from "lucide-react"

// Données de démonstration
const orders = [
  {
    id: "CMD-2024-001",
    customer: "Jean Dupont",
    email: "jean.dupont@email.com",
    date: "2024-01-15",
    status: "delivered",
    total: 299.99,
    items: 1,
    shippingAddress: "123 Rue de la Paix, Paris",
  },
  {
    id: "CMD-2024-002",
    customer: "Marie Martin",
    email: "marie.martin@email.com",
    date: "2024-01-14",
    status: "shipped",
    total: 159.99,
    items: 2,
    shippingAddress: "456 Avenue des Champs, Lyon",
  },
  {
    id: "CMD-2024-003",
    customer: "Pierre Durand",
    email: "pierre.durand@email.com",
    date: "2024-01-13",
    status: "processing",
    total: 89.99,
    items: 1,
    shippingAddress: "789 Boulevard Saint-Michel, Marseille",
  },
  {
    id: "CMD-2024-004",
    customer: "Sophie Leblanc",
    email: "sophie.leblanc@email.com",
    date: "2024-01-12",
    status: "pending",
    total: 199.99,
    items: 3,
    shippingAddress: "321 Rue Victor Hugo, Toulouse",
  },
]

const statusConfig = {
  pending: { label: "En attente", color: "bg-gray-500", action: "Confirmer" },
  processing: { label: "En préparation", color: "bg-yellow-500", action: "Expédier" },
  shipped: { label: "Expédiée", color: "bg-blue-500", action: "Marquer livrée" },
  delivered: { label: "Livrée", color: "bg-green-500", action: "Terminée" },
  cancelled: { label: "Annulée", color: "bg-red-500", action: "Archiver" },
}

export function OrdersManager() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")

  const filteredOrders = orders.filter((order) => {
    const matchesSearch =
      order.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      order.customer.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || order.status === statusFilter
    return matchesSearch && matchesStatus
  })

  const handleStatusChange = (orderId: string, newStatus: string) => {
    console.log("[v0] Changement statut commande:", { orderId, newStatus })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-sans">Gestion des commandes</h1>
          <p className="text-muted-foreground">Suivez et gérez toutes les commandes</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium font-serif">En attente</p>
                <p className="text-2xl font-bold font-sans">{orders.filter((o) => o.status === "pending").length}</p>
              </div>
              <Badge className="bg-gray-500 text-white">Nouveau</Badge>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium font-serif">En préparation</p>
                <p className="text-2xl font-bold font-sans">{orders.filter((o) => o.status === "processing").length}</p>
              </div>
              <Package className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium font-serif">Expédiées</p>
                <p className="text-2xl font-bold font-sans">{orders.filter((o) => o.status === "shipped").length}</p>
              </div>
              <Truck className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium font-serif">Livrées</p>
                <p className="text-2xl font-bold font-sans">{orders.filter((o) => o.status === "delivered").length}</p>
              </div>
              <Badge className="bg-green-500 text-white">Terminé</Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Rechercher par numéro de commande ou client..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filtrer par statut" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Tous les statuts</SelectItem>
                <SelectItem value="pending">En attente</SelectItem>
                <SelectItem value="processing">En préparation</SelectItem>
                <SelectItem value="shipped">Expédiées</SelectItem>
                <SelectItem value="delivered">Livrées</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Orders Table */}
      <Card>
        <CardHeader>
          <CardTitle className="font-sans">Commandes ({filteredOrders.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredOrders.map((order) => (
              <div key={order.id} className="flex items-center gap-4 p-4 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-medium font-sans">{order.id}</h3>
                    <Badge className={`${statusConfig[order.status as keyof typeof statusConfig].color} text-white`}>
                      {statusConfig[order.status as keyof typeof statusConfig].label}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{order.customer}</p>
                  <p className="text-sm text-muted-foreground">{order.email}</p>
                  <p className="text-xs text-muted-foreground mt-1">{order.shippingAddress}</p>
                </div>
                <div className="text-center">
                  <div className="font-medium font-serif">Articles</div>
                  <div className="text-sm">{order.items}</div>
                </div>
                <div className="text-center">
                  <div className="font-medium font-serif">Date</div>
                  <div className="text-sm">{new Date(order.date).toLocaleDateString("fr-FR")}</div>
                </div>
                <div className="text-center">
                  <div className="font-bold text-primary text-lg">{order.total.toFixed(2)}€</div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="bg-transparent">
                    <Eye className="h-4 w-4" />
                  </Button>
                  {order.status !== "delivered" && (
                    <Button
                      size="sm"
                      className="font-serif"
                      onClick={() => {
                        const nextStatus =
                          order.status === "pending"
                            ? "processing"
                            : order.status === "processing"
                              ? "shipped"
                              : "delivered"
                        handleStatusChange(order.id, nextStatus)
                      }}
                    >
                      {statusConfig[order.status as keyof typeof statusConfig].action}
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
