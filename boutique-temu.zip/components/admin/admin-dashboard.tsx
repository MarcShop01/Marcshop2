"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { AdminSidebar } from "@/components/admin/admin-sidebar"
import { ProductsManager } from "@/components/admin/products-manager"
import { OrdersManager } from "@/components/admin/orders-manager"
import { UsersManager } from "@/components/admin/users-manager"
import { ShoppingCart, Package, Users, DollarSign, Eye } from "lucide-react"
import Link from "next/link"

// Données de démonstration
const dashboardStats = {
  totalRevenue: 45678.9,
  totalOrders: 1234,
  totalProducts: 156,
  totalUsers: 2890,
  recentOrders: [
    { id: "CMD-001", customer: "Jean Dupont", amount: 299.99, status: "delivered" },
    { id: "CMD-002", customer: "Marie Martin", amount: 159.99, status: "shipped" },
    { id: "CMD-003", customer: "Pierre Durand", amount: 89.99, status: "processing" },
  ],
  topProducts: [
    { name: "Smartphone Android", sales: 45, revenue: 13495.55 },
    { name: "Casque Bluetooth", sales: 32, revenue: 2559.68 },
    { name: "Montre Connectée", sales: 28, revenue: 4479.72 },
  ],
}

const statusConfig = {
  processing: { label: "En préparation", color: "bg-yellow-500" },
  shipped: { label: "Expédiée", color: "bg-blue-500" },
  delivered: { label: "Livrée", color: "bg-green-500" },
}

export function AdminDashboard() {
  const [activeSection, setActiveSection] = useState("dashboard")

  const renderContent = () => {
    switch (activeSection) {
      case "products":
        return <ProductsManager />
      case "orders":
        return <OrdersManager />
      case "users":
        return <UsersManager />
      default:
        return (
          <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold font-sans">Tableau de bord MarcShop</h1>
                <p className="text-muted-foreground">Vue d'ensemble de votre boutique en ligne</p>
              </div>
              <Link href="/">
                <Button className="font-serif">
                  <Eye className="h-4 w-4 mr-2" />
                  Voir le site
                </Button>
              </Link>
            </div>

            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium font-serif">Chiffre d'affaires</CardTitle>
                  <DollarSign className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold font-sans">${dashboardStats.totalRevenue.toFixed(2)} USD</div>
                  <p className="text-xs text-muted-foreground">+12% par rapport au mois dernier</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium font-serif">Commandes</CardTitle>
                  <ShoppingCart className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold font-sans">{dashboardStats.totalOrders}</div>
                  <p className="text-xs text-muted-foreground">+8% par rapport au mois dernier</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium font-serif">Produits</CardTitle>
                  <Package className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold font-sans">{dashboardStats.totalProducts}</div>
                  <p className="text-xs text-muted-foreground">+5 nouveaux ce mois</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium font-serif">Utilisateurs</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold font-sans">{dashboardStats.totalUsers}</div>
                  <p className="text-xs text-muted-foreground">+15% par rapport au mois dernier</p>
                </CardContent>
              </Card>
            </div>

            <div className="grid lg:grid-cols-2 gap-6">
              {/* Commandes récentes */}
              <Card>
                <CardHeader>
                  <CardTitle className="font-sans">Commandes récentes</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {dashboardStats.recentOrders.map((order) => (
                      <div key={order.id} className="flex items-center justify-between">
                        <div>
                          <div className="font-medium font-serif">{order.id}</div>
                          <div className="text-sm text-muted-foreground">{order.customer}</div>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold">${order.amount.toFixed(2)} USD</span>
                          <Badge
                            className={`${statusConfig[order.status as keyof typeof statusConfig].color} text-white`}
                          >
                            {statusConfig[order.status as keyof typeof statusConfig].label}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Produits populaires */}
              <Card>
                <CardHeader>
                  <CardTitle className="font-sans">Produits populaires</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {dashboardStats.topProducts.map((product, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div>
                          <div className="font-medium font-serif">{product.name}</div>
                          <div className="text-sm text-muted-foreground">{product.sales} ventes</div>
                        </div>
                        <div className="font-bold text-primary">${product.revenue.toFixed(2)} USD</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        )
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="flex">
        <AdminSidebar activeSection={activeSection} onSectionChange={setActiveSection} />
        <main className="flex-1 p-8">{renderContent()}</main>
      </div>
    </div>
  )
}
