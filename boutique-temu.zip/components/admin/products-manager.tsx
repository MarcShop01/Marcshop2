"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Plus, Edit, Trash2, Search, Filter } from "lucide-react"

interface Product {
  id: number
  name: string
  price: number
  originalPrice: number
  category: string
  stock: number
  status: string
  images: string[]
  description: string
}

const statusConfig = {
  active: { label: "Actif", color: "bg-green-500" },
  inactive: { label: "Inactif", color: "bg-gray-500" },
  low_stock: { label: "Stock faible", color: "bg-yellow-500" },
  out_of_stock: { label: "Rupture", color: "bg-red-500" },
}

export function ProductsManager() {
  const [products, setProducts] = useState<Product[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null)
  const [newProduct, setNewProduct] = useState({
    name: "",
    price: "",
    originalPrice: "",
    category: "",
    stock: "",
    description: "",
    image1: "",
    image2: "",
    image3: "",
    image4: "",
  })

  useEffect(() => {
    const savedProducts = localStorage.getItem("marcshop-products")
    if (savedProducts) {
      setProducts(JSON.parse(savedProducts))
    }
  }, [])

  useEffect(() => {
    localStorage.setItem("marcshop-products", JSON.stringify(products))
  }, [products])

  const filteredProducts = products.filter((product) => product.name.toLowerCase().includes(searchTerm.toLowerCase()))

  const handleAddProduct = () => {
    if (!newProduct.name || !newProduct.price || !newProduct.stock) {
      alert("Veuillez remplir tous les champs obligatoires")
      return
    }

    const images = [newProduct.image1, newProduct.image2, newProduct.image3, newProduct.image4].filter(
      (img) => img.trim() !== "",
    )

    const product: Product = {
      id: Date.now(),
      name: newProduct.name,
      price: Number.parseFloat(newProduct.price),
      originalPrice: newProduct.originalPrice
        ? Number.parseFloat(newProduct.originalPrice)
        : Number.parseFloat(newProduct.price),
      category: newProduct.category,
      stock: Number.parseInt(newProduct.stock),
      status:
        Number.parseInt(newProduct.stock) > 10
          ? "active"
          : Number.parseInt(newProduct.stock) > 0
            ? "low_stock"
            : "out_of_stock",
      images: images,
      description: newProduct.description,
    }

    setProducts((prev) => [...prev, product])
    setIsAddDialogOpen(false)
    resetForm()
  }

  const handleDeleteProduct = (id: number) => {
    if (confirm("Êtes-vous sûr de vouloir supprimer ce produit ?")) {
      setProducts((prev) => prev.filter((p) => p.id !== id))
    }
  }

  const resetForm = () => {
    setNewProduct({
      name: "",
      price: "",
      originalPrice: "",
      category: "",
      stock: "",
      description: "",
      image1: "",
      image2: "",
      image3: "",
      image4: "",
    })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-sans">Gestion des produits</h1>
          <p className="text-muted-foreground">Gérez votre catalogue de produits MarcShop</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button className="font-serif">
              <Plus className="h-4 w-4 mr-2" />
              Ajouter un produit
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="font-sans">Ajouter un nouveau produit</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="productName" className="font-serif">
                    Nom du produit *
                  </Label>
                  <Input
                    id="productName"
                    value={newProduct.name}
                    onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="productCategory" className="font-serif">
                    Catégorie *
                  </Label>
                  <Input
                    id="productCategory"
                    value={newProduct.category}
                    onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-3">
                <Label className="font-serif text-base">Images du produit (jusqu'à 4)</Label>
                <div className="grid grid-cols-1 gap-3">
                  <div>
                    <Label htmlFor="image1" className="font-serif text-sm">
                      Image principale *
                    </Label>
                    <Input
                      id="image1"
                      type="url"
                      placeholder="https://example.com/image1.jpg"
                      value={newProduct.image1}
                      onChange={(e) => setNewProduct({ ...newProduct, image1: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="image2" className="font-serif text-sm">
                      Image 2
                    </Label>
                    <Input
                      id="image2"
                      type="url"
                      placeholder="https://example.com/image2.jpg"
                      value={newProduct.image2}
                      onChange={(e) => setNewProduct({ ...newProduct, image2: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="image3" className="font-serif text-sm">
                      Image 3
                    </Label>
                    <Input
                      id="image3"
                      type="url"
                      placeholder="https://example.com/image3.jpg"
                      value={newProduct.image3}
                      onChange={(e) => setNewProduct({ ...newProduct, image3: e.target.value })}
                    />
                  </div>
                  <div>
                    <Label htmlFor="image4" className="font-serif text-sm">
                      Image 4
                    </Label>
                    <Input
                      id="image4"
                      type="url"
                      placeholder="https://example.com/image4.jpg"
                      value={newProduct.image4}
                      onChange={(e) => setNewProduct({ ...newProduct, image4: e.target.value })}
                    />
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  Entrez les URLs complètes des images. La première image sera l'image principale.
                </p>
              </div>

              <div className="grid grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="productPrice" className="font-serif">
                    Prix de vente (USD) *
                  </Label>
                  <Input
                    id="productPrice"
                    type="number"
                    step="0.01"
                    placeholder="29.99"
                    value={newProduct.price}
                    onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="productOriginalPrice" className="font-serif">
                    Prix original (USD)
                  </Label>
                  <Input
                    id="productOriginalPrice"
                    type="number"
                    step="0.01"
                    placeholder="39.99"
                    value={newProduct.originalPrice}
                    onChange={(e) => setNewProduct({ ...newProduct, originalPrice: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="productStock" className="font-serif">
                    Stock *
                  </Label>
                  <Input
                    id="productStock"
                    type="number"
                    placeholder="50"
                    value={newProduct.stock}
                    onChange={(e) => setNewProduct({ ...newProduct, stock: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="productDescription" className="font-serif">
                  Description
                </Label>
                <Textarea
                  id="productDescription"
                  placeholder="Description détaillée du produit..."
                  value={newProduct.description}
                  onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })}
                />
              </div>
              <div className="flex justify-end gap-2">
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsAddDialogOpen(false)
                    resetForm()
                  }}
                  className="font-serif bg-transparent"
                >
                  Annuler
                </Button>
                <Button onClick={handleAddProduct} className="font-serif">
                  Ajouter le produit
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Rechercher un produit..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            <Button variant="outline" className="font-serif bg-transparent">
              <Filter className="h-4 w-4 mr-2" />
              Filtres
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Products Table */}
      <Card>
        <CardHeader>
          <CardTitle className="font-sans">Produits ({filteredProducts.length})</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredProducts.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-muted-foreground">
                Aucun produit trouvé. Commencez par ajouter votre premier produit !
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredProducts.map((product) => (
                <div key={product.id} className="flex items-center gap-4 p-4 border rounded-lg">
                  <img
                    src={product.images[0] || "/placeholder.svg?height=64&width=64"}
                    alt={product.name}
                    className="w-16 h-16 object-cover rounded-md"
                  />
                  <div className="flex-1">
                    <h3 className="font-medium font-serif">{product.name}</h3>
                    <p className="text-sm text-muted-foreground">{product.category}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="font-bold text-primary">${product.price.toFixed(2)}</span>
                      {product.originalPrice > product.price && (
                        <span className="text-sm text-muted-foreground line-through">
                          ${product.originalPrice.toFixed(2)}
                        </span>
                      )}
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="font-medium">Stock</div>
                    <div className="text-sm">{product.stock} unités</div>
                  </div>
                  <Badge className={`${statusConfig[product.status as keyof typeof statusConfig].color} text-white`}>
                    {statusConfig[product.status as keyof typeof statusConfig].label}
                  </Badge>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="bg-transparent">
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="text-destructive hover:text-destructive bg-transparent"
                      onClick={() => handleDeleteProduct(product.id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
