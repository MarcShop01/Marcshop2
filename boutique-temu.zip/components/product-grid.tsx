"use client"

import { useEffect, useState } from "react"
import { ProductCard } from "@/components/product-card"

interface Product {
  id: number
  name: string
  price: number
  originalPrice: number
  images: string[]
  rating?: number
  reviews?: number
  badge?: string
  discount?: number
  category: string
  stock: number
  status: string
  description: string
}

export function ProductGrid() {
  const [products, setProducts] = useState<Product[]>([])

  useEffect(() => {
    const loadProducts = () => {
      const savedProducts = localStorage.getItem("marcshop-products")
      if (savedProducts) {
        const parsedProducts = JSON.parse(savedProducts)
        const displayProducts = parsedProducts.map((product: Product) => ({
          ...product,
          image: product.images[0] || "/placeholder.svg?height=200&width=200",
          rating: 4.0 + Math.random() * 1.0,
          reviews: Math.floor(Math.random() * 1000) + 100,
          badge: product.stock > 50 ? "STOCK+" : product.stock < 10 ? "LIMITÉ" : "NOUVEAU",
          discount:
            product.originalPrice > product.price
              ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
              : 0,
        }))
        setProducts(displayProducts)
      } else {
        setProducts([])
      }
    }

    loadProducts()

    const handleStorageChange = (e: StorageEvent) => {
      if (e.key === "marcshop-products") {
        loadProducts()
      }
    }

    window.addEventListener("storage", handleStorageChange)

    const interval = setInterval(loadProducts, 2000)

    return () => {
      window.removeEventListener("storage", handleStorageChange)
      clearInterval(interval)
    }
  }, [])

  if (products.length === 0) {
    return (
      <div className="text-center py-12">
        <h3 className="text-xl font-semibold font-sans mb-2">Aucun produit disponible</h3>
        <p className="text-muted-foreground">Les produits seront affichés ici une fois ajoutés par l'administrateur.</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  )
}
