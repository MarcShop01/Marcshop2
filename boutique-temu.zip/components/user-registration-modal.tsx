"use client"

import type React from "react"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Mail, User } from "lucide-react"

interface UserRegistrationModalProps {
  isOpen: boolean
  onClose: (email: string) => void
}

export function UserRegistrationModal({ isOpen, onClose }: UserRegistrationModalProps) {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!email || !email.includes("@") || !name.trim()) return

    setIsSubmitting(true)

    const users = JSON.parse(localStorage.getItem("marcshop_users") || "[]")
    const newUser = {
      id: Date.now(),
      name: name.trim(),
      email,
      registeredAt: new Date().toISOString(),
      isActive: true,
      lastActivity: new Date().toISOString(),
    }

    users.push(newUser)
    localStorage.setItem("marcshop_users", JSON.stringify(users))
    localStorage.setItem("marcshop_current_user", JSON.stringify(newUser))

    setTimeout(() => {
      setIsSubmitting(false)
      onClose(email)
    }, 1000)
  }

  return (
    <Dialog open={isOpen} onOpenChange={() => {}}>
      <DialogContent className="sm:max-w-md" hideClose>
        <DialogHeader>
          <DialogTitle className="text-center font-serif text-xl">Bienvenue sur MarcShop! 🛍️</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <p className="text-center text-muted-foreground">
            Pour accéder à notre boutique, veuillez entrer vos informations
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nom complet</Label>
              <div className="relative">
                <User className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="name"
                  type="text"
                  placeholder="Votre nom complet"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Adresse Email</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  id="email"
                  type="email"
                  placeholder="votre@email.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <Button
              type="submit"
              className="w-full font-serif"
              disabled={!email || !email.includes("@") || !name.trim() || isSubmitting}
            >
              {isSubmitting ? "Inscription..." : "Accéder à MarcShop"}
            </Button>
          </form>
        </div>
      </DialogContent>
    </Dialog>
  )
}
