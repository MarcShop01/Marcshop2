"use client"

import type React from "react"

import { createContext, useContext, useState, useEffect } from "react"
import { UserRegistrationModal } from "@/components/user-registration-modal"

interface UserRegistrationContextType {
  isRegistered: boolean
  currentUser: any
  registerUser: (email: string) => void
}

const UserRegistrationContext = createContext<UserRegistrationContextType | undefined>(undefined)

export function UserRegistrationProvider({ children }: { children: React.ReactNode }) {
  const [isRegistered, setIsRegistered] = useState(false)
  const [currentUser, setCurrentUser] = useState(null)
  const [showModal, setShowModal] = useState(false)

  useEffect(() => {
    // Vérifier si l'utilisateur est déjà enregistré
    const user = localStorage.getItem("marcshop_current_user")
    if (user) {
      setCurrentUser(JSON.parse(user))
      setIsRegistered(true)
    } else {
      // Afficher le modal d'inscription après un court délai
      setTimeout(() => setShowModal(true), 1000)
    }
  }, [])

  const registerUser = (email: string) => {
    const users = JSON.parse(localStorage.getItem("marcshop_users") || "[]")
    const newUser = {
      id: Date.now(),
      email,
      registeredAt: new Date().toISOString(),
      isActive: true,
      lastActivity: new Date().toISOString(),
    }

    users.push(newUser)
    localStorage.setItem("marcshop_users", JSON.stringify(users))
    localStorage.setItem("marcshop_current_user", JSON.stringify(newUser))

    setCurrentUser(newUser)
    setIsRegistered(true)
    setShowModal(false)
  }

  return (
    <UserRegistrationContext.Provider value={{ isRegistered, currentUser, registerUser }}>
      {children}
      <UserRegistrationModal isOpen={showModal} onClose={registerUser} />
    </UserRegistrationContext.Provider>
  )
}

export function useUserRegistration() {
  const context = useContext(UserRegistrationContext)
  if (context === undefined) {
    throw new Error("useUserRegistration must be used within a UserRegistrationProvider")
  }
  return context
}
